<?php

require_once 'core/model.php';
require_once 'core/view.php';
require_once 'core/controller.php';
require_once 'core/wservice.php';
require_once 'core/dbconnection.php';
require_once 'core/kk_webconstants.php';

require_once 'core/route.php';
Route::start(); //exec routing

