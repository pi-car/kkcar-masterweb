<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of model_kkcontroller
 *
 * @author blinov_is
 */
class model_phoneapp extends Model {

    function __construct() {
        $this->dbc = new dbconnection();
    }

    public function get_data() {
        
    }

}
