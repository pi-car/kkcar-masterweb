<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of wservice
 *
 * @author blinov_is
 */

class wservice{
    
        public $model;
	function action_request()
	{
		
	}
}
