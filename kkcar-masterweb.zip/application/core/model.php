<?php
class Model
{
    public  $dbc;
        // метод выборки данных
	public function get_data()
	{
		// todo
	}
}