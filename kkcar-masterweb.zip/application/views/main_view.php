<h1>Welcome! Hola!</h1>
<p>
<img src="/images/office-small.jpg" align="left" >
This is a main page

</p>